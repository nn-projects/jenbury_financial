<?php
echo "Hello, World!\n";