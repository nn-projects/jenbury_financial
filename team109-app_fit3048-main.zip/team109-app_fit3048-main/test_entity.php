<?php
declare(strict_types=1);

require 'vendor/autoload.php';

use App\Model\Entity\TestEntity;

// Create a new TestEntity
$entity = new TestEntity();
echo "TestEntity created successfully!\n";

// Try to set a property
$entity->name = 'Test';
echo "Property set successfully: " . $entity->name . "\n";