<?php
// Script to update admin password

// Load the CakePHP bootstrap
require __DIR__ . '/config/bootstrap.php';

use Cake\Datasource\ConnectionManager;
use Authentication\PasswordHasher\DefaultPasswordHasher;

// Create a password hasher
$hasher = new DefaultPasswordHasher();

// Hash the password
$password = 'admin123';
$hashedPassword = $hasher->hash($password);

echo "Password: $password\n";
echo "Hashed Password: $hashedPassword\n";

// Update the admin user's password
$connection = ConnectionManager::get('default');
$result = $connection->execute(
    "UPDATE users SET password = :password WHERE email = :email",
    ['password' => $hashedPassword, 'email' => 'admin@jenburyfinancial.com']
);

echo "Rows affected: " . $result->rowCount() . "\n";
echo "Admin password updated successfully!\n";