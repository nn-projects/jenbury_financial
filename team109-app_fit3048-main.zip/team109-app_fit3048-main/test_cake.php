<?php
declare(strict_types=1);

require 'vendor/autoload.php';
require 'config/bootstrap.php';

use Cake\Core\Configure;
use Cake\Datasource\ConnectionManager;

// Check if the database connection is working
try {
    $connection = ConnectionManager::get('default');
    echo "Database connection: OK\n";
} catch (\Exception $e) {
    echo "Database connection error: " . $e->getMessage() . "\n";
}

// Print CakePHP version
echo "CakePHP version: " . Configure::version() . "\n";

// Try to use the TestEntity class
try {
    $entity = new \App\Model\Entity\TestEntity();
    echo "TestEntity created successfully!\n";
} catch (\Exception $e) {
    echo "TestEntity error: " . $e->getMessage() . "\n";
}

// Try to use the User entity class
try {
    $user = new \App\Model\Entity\User();
    echo "User entity created successfully!\n";
} catch (\Exception $e) {
    echo "User entity error: " . $e->getMessage() . "\n";
}

// Try to use the Course entity class
try {
    $course = new \App\Model\Entity\Course();
    echo "Course entity created successfully!\n";
} catch (\Exception $e) {
    echo "Course entity error: " . $e->getMessage() . "\n";
}

// Try to use the Module entity class
try {
    $module = new \App\Model\Entity\Module();
    echo "Module entity created successfully!\n";
} catch (\Exception $e) {
    echo "Module entity error: " . $e->getMessage() . "\n";
}

// Try to use the Content entity class
try {
    $content = new \App\Model\Entity\Content();
    echo "Content entity created successfully!\n";
} catch (\Exception $e) {
    echo "Content entity error: " . $e->getMessage() . "\n";
}

// Try to use the Purchase entity class
try {
    $purchase = new \App\Model\Entity\Purchase();
    echo "Purchase entity created successfully!\n";
} catch (\Exception $e) {
    echo "Purchase entity error: " . $e->getMessage() . "\n";
}