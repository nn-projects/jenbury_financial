<?php
declare(strict_types=1);

require 'vendor/autoload.php';
require 'config/bootstrap.php';

use Cake\ORM\Entity;
use ReflectionClass;

// Check the parent class property
$reflector = new ReflectionClass(Entity::class);
$property = $reflector->getProperty('_accessible');
echo "Parent class property type: " . ($property->hasType() ? $property->getType() : 'no type') . "\n";

// Try to create a simple entity without any properties
class SimpleEntity extends Entity
{
}

try {
    $entity = new SimpleEntity();
    echo "SimpleEntity created successfully!\n";
} catch (\Exception $e) {
    echo "SimpleEntity error: " . $e->getMessage() . "\n";
}