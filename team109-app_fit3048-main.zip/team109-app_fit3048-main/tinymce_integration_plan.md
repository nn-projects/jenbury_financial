# Plan: Replace CKEditor with TinyMCE

**Objective:** Replace CKEditor with TinyMCE for editing lesson and module content in the admin area, using CDN, inline editing, and supporting image, file, and YouTube link uploads.

**Current State:**
*   CKEditor is used in `templates/Admin/Admin/edit_lesson_content.php` and `templates/Admin/Admin/add_content.php`.
*   CKEditor is loaded via CDN.
*   CKEditor has a custom image upload configuration pointing to `/admin/uploads/ckeditor_image`.
*   No CKEditor-specific JavaScript files were found in `webroot/js`.

**Desired State (with TinyMCE):**
*   TinyMCE is used in `templates/Admin/Admin/edit_lesson_content.php` and `templates/Admin/Admin/add_content.php`.
*   TinyMCE is loaded via CDN.
*   TinyMCE uses inline editing mode.
*   TinyMCE supports basic formatting, image, file (PDF, Excel), and YouTube link uploads.
*   Relevant free open-source plugins are included.

**Plan:**

1.  **Identify Target Elements:** Confirm the specific HTML elements (likely `<textarea>` or `<div>`) in `templates/Admin/Admin/edit_lesson_content.php` and `templates/Admin/Admin/add_content.php` that will be used for inline editing with TinyMCE. Based on the search results, elements with the class `ckeditor-editor` are good candidates.
2.  **Remove CKEditor Code:**
    *   In `templates/Admin/Admin/edit_lesson_content.php`, remove the CKEditor CDN script tag (`<script src="https://cdn.ckeditor.com/ckeditor5/...">`) and the associated CKEditor initialization script block.
    *   In `templates/Admin/Admin/add_content.php`, remove the CKEditor CDN script tag and the associated CKEditor initialization script block.
3.  **Add TinyMCE CDN:**
    *   In both `templates/Admin/Admin/edit_lesson_content.php` and `templates/Admin/Admin/add_content.php`, add the TinyMCE CDN script tag. We will use the latest stable version.
4.  **Initialize TinyMCE:**
    *   In both template files, add a new JavaScript script block to initialize TinyMCE.
    *   Use `tinymce.init()` to target the elements identified in Step 1 (e.g., `selector: '.ckeditor-editor'`).
    *   Set the `inline: true` option.
    *   Configure the `plugins` option to include necessary plugins for formatting, lists, tables, media (for YouTube), image, link, code view, fullscreen, and help. Examples: `'lists link image media table code fullscreen help'`
    *   Configure the `toolbar` option to include relevant buttons corresponding to the chosen plugins. Examples: `'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | image media link | code fullscreen help'`
    *   Configure image and file upload handling. This will require setting up the `images_upload_url` and potentially `file_picker_callback` options in the TinyMCE configuration. We will need to investigate the existing upload controller (`src/Controller/Admin/UploadsController.php`) to see if the `/admin/uploads/ckeditor_image` endpoint can be adapted for TinyMCE or if a new endpoint is needed (e.g., `/admin/uploads/tinymce_upload`).
5.  **Update Upload Controller (Conditional):**
    *   Read the contents of `src/Controller/Admin/UploadsController.php` to understand how the current CKEditor image upload endpoint works.
    *   Based on the TinyMCE documentation for image and file uploads and the existing controller logic, determine if modifications are needed to `src/Controller/Admin/UploadsController.php` to handle uploads from TinyMCE correctly. This might involve creating a new action or modifying the existing one to accept and process files in the format TinyMCE expects and return the response in the format TinyMCE understands.
6.  **Testing:**
    *   After implementing the changes, thoroughly test the TinyMCE editor in both the "Add Content" and "Edit Lesson Content" admin pages.
    *   Verify that basic formatting options work correctly.
    *   Test image uploads, file uploads (PDF, Excel), and embedding YouTube links.
    *   Ensure that the content is saved and loaded correctly.

**Mermaid Diagram:**

```mermaid
graph TD
    A[Start: Replace CKEditor with TinyMCE] --> B[Identify Editor Elements in Templates];
    B --> C[Remove CKEditor Code from Templates];
    C --> D[Add TinyMCE CDN to Templates];
    D --> E[Initialize TinyMCE in Templates <br> (Inline Mode, Plugins, Toolbar)];
    E --> F{Configure TinyMCE Uploads <br> (Image, File, Media)};
    F --> G[Investigate src/Controller/Admin/UploadsController.php];
    G --> H{Update Upload Controller?};
    H -- Yes --> I[Modify src/Controller/Admin/UploadsController.php];
    H -- No --> J[Proceed to Testing];
    I --> J[Proceed to Testing];
    J --> K[Test TinyMCE Functionality <br> (Formatting, Uploads, Saving/Loading)];
    K --> L[End: Implementation Complete];