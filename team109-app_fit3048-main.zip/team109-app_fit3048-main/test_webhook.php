<?php
/**
 * Simple script to test the Stripe webhook endpoint
 */

// Set up the request URL - adjust if your local server uses a different port
$webhookUrl = 'http://localhost:8765/payments/webhook';

// Create a simple test payload that mimics a Stripe payment_intent.succeeded event
$payload = json_encode([
    'id' => 'evt_test_' . time(),
    'object' => 'event',
    'type' => 'payment_intent.succeeded',
    'data' => [
        'object' => [
            'id' => 'pi_test_' . time(),
            'object' => 'payment_intent',
            'amount' => 2000,
            'amount_received' => 2000,
            'metadata' => [
                'user_id' => 1,
                'cart_id' => 1
            ]
        ]
    ]
]);

// For debugging, let's add a special header to bypass signature verification
// This is for testing only and should never be used in production
$bypassSignatureVerification = true;

// Set up cURL
$ch = curl_init($webhookUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

$headers = ['Content-Type: application/json'];

if ($bypassSignatureVerification) {
    // Add a special header that we can check for in the controller
    $headers[] = 'X-Webhook-Test: true';
    $headers[] = 'Stripe-Signature: test_signature';
} else {
    // In a real scenario, we would generate a proper signature
    $headers[] = 'Stripe-Signature: test_signature';
}

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// Execute the request
echo "Sending test webhook request to $webhookUrl...\n";
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Output the results
echo "HTTP Response Code: $httpCode\n";
echo "Response Body: $response\n";

echo "\nCheck your logs/debug.log and logs/error.log for more details.\n";
?>